<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Website UKK 2025</title>
    <link rel="stylesheet" href="style.menu.css">
</head>

<body>
    <header>
        <h1>WEBSITE UKK 2025</h1>
        <a href="login.php" class="login-button">Login</a>
    </header>

    <main>
        <div class="content">
            <img src="image/banner-02.jpg" alt="Foto Bersama" class="main-image">
            <aside>
                <div class="info">
                    <h2>REKAYASA PERANGKAT LUNAK</h2>
                    <h3>VISI</h3>
                    <p>"Menjadikan lulusan yang tangguh dalam teknologi informasi, berkarakter, dan siap menghadapi
                        globalisasi."</p>

                    <h3>MISI</h3>
                    <ol>
                        <li>Melaksanakan pengembangan dan implementasi kurikulum.</li>
                        <li>Menyiapkan sarana dan prasarana pembelajaran produktif yang lengkap dan berkualitas.</li>
                        <li>Menjadikan insan yang kreatif, produktif, dan inovatif dalam pengembangan.</li>
                    </ol>

                    <h3>KOMPETENSI KELAS XI KOMPUTER & INFORMATIKA</h3>
                    <ol>
                        <li>Merancang dan membuat kebutuhan basis data (Database).</li>
                        <li>Membuat dan mendesain halaman web statis dan dinamis menggunakan CSS, HTML, PHP, JavaScript,
                            dll.</li>
                        <li>Membuat website secara native maupun dengan framework (CI atau Laravel).</li>
                        <li>Membuat aplikasi desktop menggunakan VB. Net.</li>
                    </ol>
                </div>
            </aside>
        </div>
    </main>


    <footer>
        <p>&copy; 2024-2025 UKK Jurusan Rekayasa Perangkat Lunak.</p>
    </footer>
</body>

</html>