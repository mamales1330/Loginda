<?php

$koneksi = mysqli_connect("localhost", "root", "", "ukk_25");

if (!$koneksi) {
    die("koneksi gagal: " . mysqli_connect_error());
} else {
    echo "koneksi berhasil";
}

?>