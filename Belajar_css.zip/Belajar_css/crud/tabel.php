<?php
session_start();
$koneksi = mysqli_connect("localhost", "root", "", "ukk_25");
$data = mysqli_query($koneksi, "SELECT * FROM tbl_siswa");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Data Tes Siswa</title>
    <link rel="stylesheet" href="tabel.css">
    <style>
    button {
        padding: 6px 12px;
        margin: 2px;
        cursor: pointer;
        background-color: #3498db;
        color: white;
        border: none;
        border-radius: 4px;
    }

    button:hover {
        background-color: #2980b9;
    }
    </style>
</head>

<body>

    <div class="header">
        <h2>Data Tes Siswa</h2>
        <a href="input.php" class="back-btn">Kembali</a>
    </div>

    <table>
        <tr>
            <th>No</th>
            <th>NIS</th>
            <th>Nomor Tes</th>
            <th>Tanggal Tes</th>
            <th>Kesiapan Tes</th>
            <?php if ($_SESSION['status'] === 'guru') : ?>
            <th>Aksi</th>
            <?php endif; ?>
        </tr>

        <?php
  $no = 1;
  while ($row = mysqli_fetch_assoc($data)) :
  ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $row['nis']; ?></td>
            <td><?php echo $row['nomor_test']; ?></td>
            <td><?php echo $row['tanggal_tes']; ?></td>
            <td><?php echo ucfirst($row['bersedia_mengikutites']); ?></td>
            <?php if ($_SESSION['status'] === 'guru') : ?>
            <td>
                <!-- Tombol Edit -->
                <form action="edit.php" method="get" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $row['nis']; ?>">
                    <button type="submit">Edit</button>
                </form>

                <!-- Tombol Hapus -->
                <form action="hapus.php" method="get" style="display:inline;"
                    onsubmit="return confirm('Yakin ingin menghapus?');">
                    <input type="hidden" name="id" value="<?php echo $row['nis']; ?>">
                    <button type="submit">Delete</button>
                </form>
            </td>
            <?php endif; ?>
        </tr>
        <?php endwhile; ?>
    </table>

</body>

</html>