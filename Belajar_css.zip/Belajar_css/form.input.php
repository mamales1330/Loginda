<?php
session_start();
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Form Input Data Siswa</title>
    <link rel="stylesheet" href="form.input.css">
</head>

<body>
    <header>
        <img src="image/banner-02.jpg" alt="Logo Sekolah" class="logo">
        <span><strong>Selamat Datang, <?php echo $_SESSION['username']; ?> |</strong></span>
        <a href="login.php" class="logout-button">Logout</a>
    </header>

    <nav>
        <button class="nav-button">Data Tes</button>
    </nav>

    <main>
        <h2>Form Input Data Siswa</h2>
        <div class="form-card">
            <form action="simpan_data.php" method="post">
                <label for="nis">NIS:</label>
                <input type="text" name="nis" id="nis" required>

                <label for="nomor_tes">Nomor Tes:</label>
                <input type="text" name="nomor_tes" id="nomor_tes" required>

                <label for="tanggal_tes">Tanggal Tes:</label>
                <input type="date" name="tanggal_tes" id="tanggal_tes" required>

                <label for="bersedia">Bersedia Mengikuti Tes:</label>
                <select name="bersedia" id="bersedia" required>
                    <option value="">-- Pilih --</option>
                    <option value="Ya">Ya</option>
                    <option value="Tidak">Tidak</option>
                </select>

                <button type="submit" class="submit-button">Simpan Data</button>
            </form>
        </div>
    </main>
</body>

</html>