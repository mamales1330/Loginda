<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = mysqli_real_escape_string($koneksi, $_POST["username"]);
  $password = mysqli_real_escape_string($koneksi, $_POST["password"]);
  $status   = mysqli_real_escape_string($koneksi, $_POST["status"]);

  // Proses Upload Foto
  $foto = $_FILES["foto"]["name"];
  $tmp  = $_FILES["foto"]["tmp_name"];
  $size = $_FILES["foto"]["size"];
  $ext  = strtolower(pathinfo($foto, PATHINFO_EXTENSION));
  $allowed = ["jpg", "jpeg", "png"];

  if (in_array($ext, $allowed) && $size <= 2097152) {
    $namafile = uniqid() . "." . $ext;
    move_uploaded_file($tmp, "uploads/" . $namafile);

    // Simpan ke DB
    $query = "INSERT INTO tbl_user (username, password, foto, status) 
              VALUES ('$username', '$password', '$namafile', '$status')";
    if (mysqli_query($koneksi, $query)) {
      echo "<script>alert('User berhasil didaftarkan'); window.location.href='login.php';</script>";
    } else {
      echo "Gagal menyimpan ke database: " . mysqli_error($koneksi);
    }
  } else {
    echo "<script>alert('Gagal upload. Pastikan file JPG/PNG dan ukuran < 2MB.');</script>";
  }
}
?>


<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="register.css">
    <title>Register User</title>
</head>

<body>

    <header class="main-header">
        <div class="logo-title">

            <img src="image/WhatsApp Image 2025-05-07 at 11.28.51_f337f05b.jpg" alt="Logo" class="logo">



            <h1>Register User</h1>
        </div>

        <nav>
            <a href="menu.php">Home</a>
        </nav>
    </header>


    <div class="register-wrapper">
        <form class="register-form" action="" method="POST" enctype="multipart/form-data">

            <h2>Register User</h2>

            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <label for="foto">Foto</label>

            <input type="file" id="foto" name="foto" accept="image/png, image/jpeg" required>

            <small>PNG, JPG up to 2MB</small>

            <label for="status">Status</label>

            <select id="status" name="status" required>
                <option value="">-- Pilih --</option>
                <option value="siswa">Siswa</option>
                <option value="guru">Guru</option>
            </select>

            <button type="submit" class="register-btn">Register</button>
            <br>
            <br>
            <a href="login.php">Sudah Punya Akun?</a>
        </form>
    </div>


    <footer>
        <p>© UKK Tahun Pelajaran 2024/2025.</p>
    </footer>
</body>

</html>